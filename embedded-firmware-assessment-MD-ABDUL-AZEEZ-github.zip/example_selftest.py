#!/usr/bin/env python3
"""
example_selftest.py -- CANDIDATE SELF-CHECK (not the grading script)

This only confirms your functions are wired up correctly and pass a
couple of easy, obvious cases. It does NOT cover edge cases, error
paths, timing, or concurrency -- passing this script does not mean
your submission is complete or correct. It exists so you can sanity
check basic plumbing before you spend time on the harder edge cases.

Usage:
    python3 example_selftest.py
(run from the same directory as candidate.c, mock_peripheral.h, hw_sim.c)
"""

import ctypes
import hashlib
import os
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))

# Integrity pins for the files you are not allowed to edit. Regenerate with
#     sha256sum hw_sim.c hw_sim.h mock_peripheral.h
# if one of them ever legitimately changes -- otherwise every run warns.
PROTECTED_SHA256 = {
    "hw_sim.c":          "d6b40753ab60857d43421f6c535f16109a2566ef7a6615d8429281ff63df8e68",
    "hw_sim.h":          "c5c317cb29b32ba4539c9d01bd4c76989c72ddfade996fed81850cf4b05ea66f",
    "mock_peripheral.h": "3987d4a65b876e53455c99a94895b9dfee680819b2ddaf3006e8222fc056b457",
}


def check_protected_files():
    """Return a list of (filename, reason) for files that are missing or modified."""
    bad = []
    for fname, expected in sorted(PROTECTED_SHA256.items()):
        path = os.path.join(HERE, fname)
        if not os.path.isfile(path):
            bad.append((fname, "missing"))
            continue
        with open(path, "rb") as f:
            actual = hashlib.sha256(f.read()).hexdigest()
        if actual != expected:
            bad.append((fname, f"modified (sha256 {actual[:12]}...)"))
    return bad


def warn_if_tampered():
    bad = check_protected_files()
    if not bad:
        return
    print("!" * 70)
    print("WARNING: do-not-edit files have been changed:")
    for fname, reason in bad:
        print(f"    {fname}  -- {reason}")
    print("")
    print("Grading runs against our own clean copies of these files, so any")
    print("change you make here will be discarded. If your code depends on")
    print("your edits, it will fail when we grade it. Restore the originals.")
    print("!" * 70)
    print("")


def build():
    so_path = os.path.join(tempfile.gettempdir(), "candidate_selftest.so")
    cmd = [
        "gcc", "-shared", "-fPIC", "-pthread", "-O0", "-Wall",
        "-I", HERE, "-o", so_path,
        os.path.join(HERE, "hw_sim.c"),
        os.path.join(HERE, "candidate.c"),
    ]
    proc = subprocess.run(cmd, capture_output=True, text=True)
    if proc.returncode != 0:
        print("COMPILATION FAILED:\n")
        print(proc.stderr)
        sys.exit(1)
    if proc.stderr.strip():
        print("compiler warnings (fix these before submitting):\n")
        print(proc.stderr)
    return so_path


def bind(lib):
    lib.hw_sim_reset.restype = None
    lib.hw_sim_peek.restype = ctypes.c_uint32
    lib.hw_sim_peek.argtypes = [ctypes.c_uint32]

    lib.get_field.restype = ctypes.c_uint32
    lib.get_field.argtypes = [ctypes.c_uint32, ctypes.c_uint32, ctypes.c_uint32]
    lib.set_field.restype = ctypes.c_uint32
    lib.set_field.argtypes = [ctypes.c_uint32, ctypes.c_uint32, ctypes.c_uint32, ctypes.c_uint32]

    lib.spx_init.restype = None
    lib.spx_init.argtypes = [ctypes.c_uint8]
    lib.spx_send_byte.restype = ctypes.c_int
    lib.spx_send_byte.argtypes = [ctypes.c_uint8]
    lib.spx_is_busy.restype = ctypes.c_bool

    lib.counter_isr_increment.restype = None
    lib.counter_read.restype = ctypes.c_uint32

    lib.rb_push.restype = ctypes.c_int
    lib.rb_push.argtypes = [ctypes.c_uint8]
    lib.rb_pop.restype = ctypes.c_int
    lib.rb_pop.argtypes = [ctypes.POINTER(ctypes.c_uint8)]


def check(label, ok):
    print(f"[{'PASS' if ok else 'FAIL'}] {label}")


def main():
    warn_if_tampered()
    print("Building candidate.c ...")
    so_path = build()
    lib = ctypes.CDLL(so_path)
    bind(lib)
    print("Build OK.\n")

    # ---- Task 1 examples ----------------------------------------------
    print("-- Task 1: bit field helpers --")
    check("get_field(0b101100, 2, 3) == 0b011",
          lib.get_field(0b101100, 2, 3) == 0b011)
    check("get_field(0xF0, 4, 4) == 0xF",
          lib.get_field(0xF0, 4, 4) == 0xF)
    check("set_field(0x00, 0, 4, 0xA) == 0x0A",
          lib.set_field(0x00, 0, 4, 0xA) == 0x0A)
    print()

    # ---- Task 2 examples -----------------------------------------------
    print("-- Task 2: SPX-100 driver (happy path only) --")
    lib.hw_sim_reset()
    lib.spx_init(3)
    ctrl = lib.hw_sim_peek(0x00)
    check("after spx_init(3), CTRL bit0 (EN) is set",
          (ctrl & 0x1) == 0x1)
    check("after spx_init(3), CLKDIV field (bits 4:2) == 3",
          ((ctrl >> 2) & 0x7) == 3)

    lib.hw_sim_reset()
    lib.spx_init(1)
    rc = lib.spx_send_byte(0xAB)
    check("spx_send_byte() on a healthy peripheral returns 0", rc == 0)
    print()

    # ---- Task 3 example --------------------------------------------------
    print("-- Task 3: counter (single-threaded sanity only) --")
    lib.hw_sim_reset()
    for _ in range(5):
        lib.counter_isr_increment()
    check("counter_read() == 5 after 5 single-threaded increments",
          lib.counter_read() == 5)
    print("  (this script does NOT test the concurrency bug -- the real")
    print("   harness stresses this with many threads.)")
    print()

    # ---- Task 4 examples --------------------------------------------------
    print("-- Task 4: ring buffer (basic push/pop only) --")
    lib.hw_sim_reset()
    ok = lib.rb_push(0x11) == 0 and lib.rb_push(0x22) == 0
    out = ctypes.c_uint8(0)
    ok = ok and lib.rb_pop(ctypes.byref(out)) == 0 and out.value == 0x11
    ok = ok and lib.rb_pop(ctypes.byref(out)) == 0 and out.value == 0x22
    check("push(0x11), push(0x22), pop()==0x11, pop()==0x22", ok)

    lib.hw_sim_reset()
    rc = lib.rb_pop(ctypes.byref(out))
    check("pop() on an empty buffer returns -1", rc == -1)
    print()

    print("Self-check complete. This does NOT cover error paths, the")
    print("hardware errata, timing/polling correctness, or concurrency --")
    print("re-read the task comments in candidate.c for the full")
    print("requirements before you consider a task done.")


if __name__ == "__main__":
    main()
