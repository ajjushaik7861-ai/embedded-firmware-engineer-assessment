# Embedded Firmware Engineer Assessment

**Candidate:** MD ABDUL AZEEZ  
**Email:** mdabdulazeez1602@gmail.com

## Overview

This repository contains my solution for the Embedded Firmware Engineer assessment.

The implementation is written in C and covers:

1. Generic 32-bit bit-field helpers
2. SPX-100 peripheral driver
3. ISR-shared counter using C11 atomics
4. ISR-safe single-producer/single-consumer ring buffer
5. Explanation of safe write-1-to-clear handling

## Files

- `candidate.c` — candidate implementation/submission
- `mock_peripheral.h` — supplied peripheral definitions
- `hw_sim.h` — supplied hardware simulator header
- `hw_sim.c` — supplied hardware simulator
- `example_selftest.py` — supplied example self-test

## Build

Use GCC with C11:

```bash
gcc -std=c11 -Wall -Wextra -pedantic -o selftest hw_sim.c
```

If the supplied self-test has its own build/run instructions, follow those instructions exactly.

## Notes

The solution pays particular attention to:

- avoiding undefined behavior for 32-bit bit-field operations
- the SPX-100 Errata A3 initialization sequence
- write-1-to-clear status flags
- bounded polling and timeout handling
- atomic access to ISR-shared state
- acquire/release ordering for the SPSC ring buffer

## Submission

If the assessment asks for a GitHub repository URL, submit the URL of this repository.

Before submission, verify the repository contents against the assessment instructions and remove any files that the assessment explicitly says must not be submitted.
