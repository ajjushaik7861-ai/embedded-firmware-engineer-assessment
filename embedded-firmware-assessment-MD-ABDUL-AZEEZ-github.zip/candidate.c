/* =====================================================================
 * CANDIDATE METADATA
 * =====================================================================
 * NAME:    MD ABDUL AZEEZ
 * EMAIL:   mdabdulazeez1602@gmail.com
 * GITHUB:  <add your GitHub profile/repository URL after creating the repository>
 * ===================================================================== */

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdatomic.h>
#include "mock_peripheral.h"


/* =====================================================================
 * TASK 1 -- Generic bit-field helpers
 * ===================================================================== */

uint32_t get_field(uint32_t reg_val, uint32_t bit_offset, uint32_t width)
{
    /* width == 32 needs special handling because shifting by 32 is
       undefined in C. */
    if (width == 32U)
        return reg_val;

    return (reg_val >> bit_offset) & ((1U << width) - 1U);
}

uint32_t set_field(uint32_t reg_val, uint32_t bit_offset,
                   uint32_t width, uint32_t value)
{
    uint32_t mask;

    /* width == 32 means the complete 32-bit word is the field. */
    if (width == 32U)
        return value;

    mask = ((1U << width) - 1U) << bit_offset;

    /* Clear the old field, then insert the new field. */
    reg_val &= ~mask;
    reg_val |= (value << bit_offset) & mask;

    return reg_val;
}


/* =====================================================================
 * TASK 2 -- SPX-100 driver
 * ===================================================================== */

bool spx_is_enabled(void)
{
    uint32_t ctrl = reg_read(SPX_CTRL_OFFSET);
    return get_field(ctrl, SPX_CTRL_EN_BIT, 1U) != 0U;
}

void spx_init(uint8_t clkdiv)
{
    uint32_t ctrl;

    /*
     * Errata A3:
     * STATUS must be read once before the first CTRL write.
     */
    (void)reg_read(SPX_STATUS_OFFSET);

    /*
     * Build CTRL from scratch.
     * Only EN and CLKDIV are needed. START and IE remain 0.
     * Reserved bits therefore remain 0.
     */
    ctrl = 0U;
    ctrl = set_field(ctrl, SPX_CTRL_EN_BIT, 1U, 1U);
    ctrl = set_field(ctrl, SPX_CTRL_CLKDIV_BIT,
                     SPX_CTRL_CLKDIV_WIDTH, clkdiv & 0x07U);

    reg_write(SPX_CTRL_OFFSET, ctrl);
}

int spx_send_byte(uint8_t data)
{
    uint32_t status;
    uint32_t ctrl;
    uint32_t poll_count = 0U;

    /*
     * Clear DONE and ERR using write-1-to-clear.
     * BUSY is unaffected by this write.
     */
    reg_write(SPX_STATUS_OFFSET,
              (1U << SPX_STATUS_DONE_BIT) |
              (1U << SPX_STATUS_ERR_BIT));

    /* Load the byte before starting the transfer. */
    reg_write(SPX_TXDATA_OFFSET, data);

    /*
     * Read the existing CTRL so EN and CLKDIV are preserved.
     * Only START is changed.
     */
    ctrl = reg_read(SPX_CTRL_OFFSET);
    ctrl = set_field(ctrl, SPX_CTRL_START_BIT, 1U, 1U);
    reg_write(SPX_CTRL_OFFSET, ctrl);

    /*
     * Poll until:
     *   - ERR is set -> hardware error
     *   - BUSY is 0 and DONE is 1 -> success
     *   - 2,000,000 polls are reached -> timeout
     */
    while (poll_count < 2000000U) {
        status = reg_read(SPX_STATUS_OFFSET);

        if (get_field(status, SPX_STATUS_ERR_BIT, 1U) != 0U)
            return -1;

        if (get_field(status, SPX_STATUS_BUSY_BIT, 1U) == 0U &&
            get_field(status, SPX_STATUS_DONE_BIT, 1U) != 0U)
            return 0;

        poll_count++;
    }

    return -2;
}

bool spx_is_busy(void)
{
    uint32_t status = reg_read(SPX_STATUS_OFFSET);
    return get_field(status, SPX_STATUS_BUSY_BIT, 1U) != 0U;
}


/* =====================================================================
 * TASK 3 -- ISR-shared counter
 * ===================================================================== */

static _Atomic uint32_t g_counter = 0U;

void counter_isr_increment(void)
{
    /*
     * Atomic increment prevents two concurrent increments from
     * reading the same old value and losing an update.
     */
    atomic_fetch_add_explicit(&g_counter, 1U, memory_order_relaxed);
}

uint32_t counter_read(void)
{
    return atomic_load_explicit(&g_counter, memory_order_relaxed);
}

/*
 * Explanation:
 * The original g_counter = g_counter + 1 operation is a read-modify-write,
 * so concurrent interrupt/thread updates can overwrite each other and lose
 * increments. I made the counter atomic and used an atomic fetch-add, so
 * each increment is performed as one indivisible operation.
 */


/* =====================================================================
 * TASK 4 -- ISR-safe single-producer/single-consumer ring buffer
 * ===================================================================== */

#define RB_CAPACITY 16U

static uint8_t rb_data[RB_CAPACITY];

/*
 * head: next position where the producer writes.
 * tail: next position where the consumer reads.
 *
 * Each index has one owner:
 *   producer owns head
 *   consumer owns tail
 *
 * Atomic acquire/release operations make the data visible safely
 * between the two contexts.
 */
static _Atomic uint32_t rb_head = 0U;
static _Atomic uint32_t rb_tail = 0U;

int rb_push(uint8_t byte)
{
    uint32_t head = atomic_load_explicit(&rb_head, memory_order_relaxed);
    uint32_t tail = atomic_load_explicit(&rb_tail, memory_order_acquire);

    /* If advancing head would equal tail, the buffer is full. */
    if ((head - tail) >= RB_CAPACITY)
        return -1;

    rb_data[head % RB_CAPACITY] = byte;

    /*
     * Publish the byte only after it has been written.
     */
    atomic_store_explicit(&rb_head, head + 1U, memory_order_release);

    return 0;
}

int rb_pop(uint8_t *out)
{
    uint32_t tail;
    uint32_t head;

    if (out == NULL)
        return -1;

    tail = atomic_load_explicit(&rb_tail, memory_order_relaxed);
    head = atomic_load_explicit(&rb_head, memory_order_acquire);

    /* No unread data. */
    if (tail == head)
        return -1;

    *out = rb_data[tail % RB_CAPACITY];

    /*
     * Release the slot after reading it so the producer can reuse it.
     */
    atomic_store_explicit(&rb_tail, tail + 1U, memory_order_release);

    return 0;
}


/* =====================================================================
 * TASK 5 -- Short answer
 * =====================================================================
 *
 * ANSWER:
 * Use separate write-1-to-clear writes for the two independent flags.
 * The ISR should write only (1U << DONE_BIT), while the main loop should
 * write only (1U << ERR_BIT). I would not use a read-modify-write of
 * STATUS because the flags can change asynchronously and the read value
 * may become stale before the write. Separate W1C writes ensure each
 * context clears only the flag it owns.
 */
