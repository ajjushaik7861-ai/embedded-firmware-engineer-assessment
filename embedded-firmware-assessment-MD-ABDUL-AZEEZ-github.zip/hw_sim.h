/* Internal simulator control/inspection API. NOT part of the candidate
 * spec -- this header is used only by the grading harness (via ctypes)
 * to reset the simulated hardware and inspect its state between test
 * cases. Candidates should never need to call these directly, and
 * doing so will not help pass the driver task since the harness
 * resets state before every test vector regardless. */
#ifndef HW_SIM_H
#define HW_SIM_H

#include <stdint.h>

/* Reset simulated hardware to power-on-reset state and clear all
 * internal bookkeeping (errata latch, transfer log, etc). Must be
 * called before each independent test case. */
void hw_sim_reset(void);

/* Raw peek at a register's current value, bypassing side effects.
 * Used by the harness to assert exact expected register contents. */
uint32_t hw_sim_peek(uint32_t offset);

/* Returns 1 if the CTRL write-enable latch is armed (i.e. STATUS has
 * been read at least once since reset), else 0. Used by the harness
 * to independently confirm the errata was respected. */
int hw_sim_latch_armed(void);

/* Returns the number of times STATUS was read since last reset. */
uint32_t hw_sim_status_read_count(void);

/* Returns the number of TXDATA writes and CTRL START writes seen
 * since reset, for sequencing checks. */
uint32_t hw_sim_txdata_write_count(void);
uint32_t hw_sim_start_write_count(void);

/* Forces the NEXT transfer (regardless of whether TXDATA was loaded)
 * to resolve with ERR instead of DONE. Used by the harness to test
 * that a driver correctly surfaces a hardware error instead of
 * assuming success once BUSY clears. */
void hw_sim_force_next_error(void);

/* Configures how many milliseconds a simulated transfer takes before
 * BUSY clears and DONE sets. Lets the harness force real polling
 * (candidate cannot assume the transfer is instantaneous). */
void hw_sim_set_transfer_delay_ms(unsigned int ms);

#endif /* HW_SIM_H */
